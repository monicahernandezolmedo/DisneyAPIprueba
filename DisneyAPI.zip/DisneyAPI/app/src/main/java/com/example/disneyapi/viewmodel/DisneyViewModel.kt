package com.example.disneyapi.viewmodel

import DisneyCharacter
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.HttpException
class DisneyViewModel : ViewModel() {
    // Cambia characterList para que sea una lista de DisneyCharacter
    var characterList = mutableStateOf<List<DisneyCharacter>>(emptyList())
    var errorMessage = mutableStateOf<String?>(null)

    // Función para obtener todos los personajes
    fun getAllCharacters() {
        viewModelScope.launch {
            try {
                val response = DisneyApi.retrofitService.getAllCharacters() // Asegúrate de tener esta función en tu API
                characterList.value = response.data  // Asigna la lista de personajes
                errorMessage.value = null
            } catch (e: HttpException) {
                if (e.code() == 404) {
                    errorMessage.value = "Characters not found"
                } else {
                    errorMessage.value = "Error: ${e.message()}"
                }
                characterList.value = emptyList() // Si ocurre un error, limpia la lista
            } catch (e: Exception) {
                errorMessage.value = "Error: ${e.message}"
                characterList.value = emptyList()
            }
        }
    }
}
