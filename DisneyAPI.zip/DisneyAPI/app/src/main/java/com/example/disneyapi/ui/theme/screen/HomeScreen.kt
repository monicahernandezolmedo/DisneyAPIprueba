import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.disneyapi.viewmodel.DisneyViewModel
@Composable
fun HomeScreen(viewModel: DisneyViewModel = viewModel()) {
    val characterList by viewModel.characterList
    val errorMessage by viewModel.errorMessage

    // Llamar a la función para obtener personajes al iniciar la pantalla
    LaunchedEffect(Unit) {
        viewModel.getAllCharacters()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {
        if (errorMessage != null) {
            Text(text = errorMessage ?: "Unknown Error")
        } else {
            if (if (characterList.isNotEmpty()) {
                true
            } else {
                false
            }
            ) {
                LazyColumn {
                    items(characterList) { character ->
                        CharacterTextItem(character = character) // Pasamos el objeto DisneyCharacter
                    }
                }
            } else {
                Text(text = "No characters available")
            }
        }
    }
}

@Composable
fun CharacterTextItem(character: DisneyCharacter) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text(text = "Name: ${character.name}")
        Text(text = "Films: ${character.films.joinToString(", ")}")
        Text(text = "Enemies: ${character.enemies.joinToString(", ")}")
        Text(text = "Image URL: ${character.imageUrl}")
        Spacer(modifier = Modifier.height(8.dp))
    }
}
